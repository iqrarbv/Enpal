declare module "@salesforce/apex/WidgetUtility.IsNestedString" {
  export default function IsNestedString(param: {input: any}): Promise<any>;
}
