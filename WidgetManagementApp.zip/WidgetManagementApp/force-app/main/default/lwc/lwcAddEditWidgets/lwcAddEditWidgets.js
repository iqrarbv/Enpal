import { LightningElement, api, wire, track } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { getRecord,updateRecord,createRecord } from 'lightning/uiRecordApi';
import strUserId from '@salesforce/user/Id';
import PROFILE_NAME_FIELD from '@salesforce/schema/User.Profile.Name';
import CheckNestedValue from '@salesforce/apex/WidgetUtility.IsNestedString';
import { NavigationMixin } from 'lightning/navigation';



const Wfields = [
    'Widget__c.Value__c',
];

export default class LwcAddEditWidgets extends NavigationMixin(LightningElement) {
    @api recordId;
    @track value;
    @track profilename;

    @wire(getRecord, { recordId: '$recordId', fields: Wfields })
    getwidgets({ data, error }) {
        if (data) {
            this.value = data.fields.Value__c.value;
        } else if (error) {
            window.console.log("Error");
        }
    }

    @wire(getRecord, {
        recordId: strUserId,
        fields: [PROFILE_NAME_FIELD]
    }) wireuser({
        error,
        data
    }) {
        if (error) {
            const evt = new ShowToastEvent({
                title: "Error",
                message: error.toString(),
                variant: "error",
            }); 
            this.dispatchEvent(evt);
        } else if (data) {
            this.profilename = data.fields.Profile.value.fields.Name.value;
        }
    }

    handleClick(event) {
        this.validateFields();
        CheckNestedValue({ input: this.value })
        .then((result) => {
            
            if(result || this.profilename == 'System Administrator' || this.profilename == 'Widget Master'){
                if(this.recordId != null){
                    this.updateWidget();
                }
                else{
                    this.createWidget();
                }
            }else{
                const evt = new ShowToastEvent({
                    title: "Error",
                    message: "Oops! you can not save because value is not properly nested.",
                    variant: "error",
                }); 
                this.dispatchEvent(evt);
            }

        })
        .catch((error) => {
            console.log('error::',error);
            const evt = new ShowToastEvent({
                title: "Error",
                message: error.body.message,
                variant: "error",
            }); 
            this.dispatchEvent(evt);
        });
    }

    ValueOnChange(event){
        this.value = event.target.value;
    }


    createWidget() {
        const fields = {};
        fields["Value__c"] = this.value;

        const recordInput = { apiName: "Widget__c", fields };
        createRecord(recordInput)
            .then(widget => {
                this.recordId = widget.id;
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Success',
                        message: 'Widget created successfully!',
                        variant: 'success',
                    }),
                );
                this.navigateToRecordPage();
            })
            .catch(error => {
                console.log('error::',error);
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Error creating record',
                        message: error.body.message,
                        variant: 'error',
                    }),
                );
            });
    }

    updateWidget() {
        console.log('this.value::'+this.value);
        let record = {
            fields: {
                Id: this.recordId,
                Value__c: this.value,
            },
        };
        updateRecord(record)
            // eslint-disable-next-line no-unused-vars
            .then(() => {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Success',
                        message: 'Record Is Updated',
                        variant: 'sucess',
                    }),
                );
                this.navigateToRecordPage();    
            })
            .catch(error => {
                console.log('error::',error);
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Error on data save',
                        message: error.body.message,
                        variant: 'sucess',
                    }),
                );
            });
    }

    validateFields() {
        this.template.querySelectorAll('lightning-textarea').forEach(element => {
            
            if(element.reportValidity() == false){
                event.preventDefault();
            }
            
            
        });
    }

    navigateToRecordPage() {
        console.log('t::');
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: this.recordId,
                objectApiName: 'Widget__c',
                actionName: 'view'
            }
        });
}


}